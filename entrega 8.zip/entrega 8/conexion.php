<?php 
$basedatos =  mysqli_connect("localhost", "root", "", "phpintermedio") or exit ("No se puede conectar con la base de datos");
?>